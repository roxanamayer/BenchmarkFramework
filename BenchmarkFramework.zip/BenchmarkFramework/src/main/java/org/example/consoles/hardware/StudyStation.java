package org.example.consoles.hardware;

import org.example.consoles.components.ProcessingUnits;
import org.example.consoles.components.Software;
import org.example.consoles.hardware.Console;

import java.util.ArrayList;

public class StudyStation extends Console {



    public StudyStation(int versionsnummer, ArrayList software, ProcessingUnits processingUnit){
        super(versionsnummer, software, processingUnit);

    }

    public void setVersionsnummer(int versionsnummer) {
        this.versionsnummer = versionsnummer;
    }

    public int getVersionsnummer() {
        return versionsnummer;
    }


    public ProcessingUnits getProcessingUnits(){
        return processingUnit;
    }

    public double getPerformancewertStudyStation(){
        return getProcessingUnits().getPerformancewert();
    }
}
