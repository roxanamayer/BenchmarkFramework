package org.example.consoles.benchmarkalgorithmn;

import org.example.consoles.components.Software;
import org.example.consoles.hardware.Console;
import org.example.consoles.hardware.StudyStation;

public class Benchmark {
   // Console c1 = new StudyStation();


    public void executeBenchmark(Console c1){
        //getPerformancewertStudyStation();



    }
}
