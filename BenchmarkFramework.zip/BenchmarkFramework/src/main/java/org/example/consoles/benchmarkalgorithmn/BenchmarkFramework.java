package org.example.consoles.benchmarkalgorithmn;

import org.example.consoles.components.Software;
import org.example.consoles.hardware.Console;
import org.example.consoles.hardware.StudyStation;

import java.util.ArrayList;

public class BenchmarkFramework extends Benchmark {
    public static void main(String[] args) {


        Software software1 = new Software("T1", 19.0);
        Software software2 = new Software("T2", 20.0);
        Software software3 = new Software("T3", 21.0);

        ArrayList <Software> softwareTest = new ArrayList<>();
        softwareTest.add(software1);
        softwareTest.add(software2);
        softwareTest.add(software3);


        for (Software s1 : softwareTest){
            System.out.println(s1.getRechenverbrauch() + s1.getTitel());
        }



    }
}
