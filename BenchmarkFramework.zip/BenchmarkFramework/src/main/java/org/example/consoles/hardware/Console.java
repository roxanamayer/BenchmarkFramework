package org.example.consoles.hardware;

import org.example.consoles.components.ProcessingUnits;
import org.example.consoles.components.Software;

import java.util.ArrayList;

public class Console {

     int versionsnummer;
     ProcessingUnits processingUnit;
     ArrayList software = new ArrayList<Software>();

     public Console(int versionsnummer, ArrayList software, ProcessingUnits processingUnit){
          this.versionsnummer=versionsnummer;
          this.software=software;
          this.processingUnit=processingUnit;

     }
}
